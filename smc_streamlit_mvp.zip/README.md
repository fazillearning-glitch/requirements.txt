# SMC MVP – Streamlit Site

This is a free, open-source mini site that computes a simplified SMC signal for XAUUSD:

- M15 & H1 BOS/CHOCH bias
- M15 Order Block with FVG
- M5 tap + volume rise (using GC=F futures volume as proxy)
- Telegram push alert (optional)

## Quick start
1. Create a GitHub repo and add these files: `requirements.txt`, `app.py`.
2. Deploy on Streamlit Community Cloud (New app → pick repo → deploy).
3. Open the site, keep defaults, and optionally enter Telegram bot credentials to receive alerts.

_Data source_: Yahoo Finance (may be delayed). For production, switch to a broker/API feed.
