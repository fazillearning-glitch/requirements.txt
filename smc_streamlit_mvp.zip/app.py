import os, time, requests
import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf
from datetime import datetime

st.set_page_config(page_title="SMC MVP – XAUUSD", layout="wide")

# ---------------- UI ----------------
st.title("SMC MVP – XAUUSD (M15/H1 bias + M15 OB with FVG + M5 tap + volume)")
with st.sidebar:
    st.markdown("**Data**")
    price_symbol = st.text_input("Price symbol (Yahoo)", value="XAUUSD=X")
    vol_proxy_symbol = st.text_input("Volume proxy (Yahoo, futures)", value="GC=F")
    fvg_min_usd = st.number_input("Min FVG size (USD)", value=0.20, min_value=0.0, step=0.05)
    sl_usd = st.number_input("Stop beyond OB (USD)", value=1.0, min_value=0.1, step=0.1)
    vol_len = st.number_input("M5 Volume SMA length", value=20, min_value=5, step=1)
    vol_mult = st.number_input("Volume rise multiplier", value=1.20, min_value=1.0, step=0.05)
    session_filter = st.text_input("Session (HHMM-HHMM, broker time)", value="0000-2400")
    auto_refresh_sec = st.number_input("Auto-refresh (sec, 0=off)", value=0, min_value=0, max_value=300, step=5)

    st.markdown("---")
    st.markdown("**Telegram (optional)**")
    tg_enable = st.checkbox("Send Telegram alert on signal", value=False)
    tg_token = st.text_input("Bot token", type="password") if tg_enable else ""
    tg_chat = st.text_input("Chat ID") if tg_enable else ""

st.caption("⚠️ Yahoo data may be delayed. Use this for learning/validation; for live trading we’ll switch to a broker/API later.")

# ---------------- Data ----------------
def dl(tkr, interval="5m", period="7d"):
    df = yf.download(tkr, interval=interval, period=period, progress=False)
    if df.empty:
        return df
    df = df.rename(columns=str.title)[["Open","High","Low","Close","Volume"]]
    return df.dropna()

m5 = dl(price_symbol, "5m", "7d")
if m5.empty:
    st.error("No data from Yahoo. Try again later or change symbol.")
    st.stop()

# volume proxy (GC=F has real volume; FX metals often don’t)
m5v = dl(vol_proxy_symbol, "5m", "7d")[["Volume"]]
m5["VolProxy"] = m5v.reindex(m5.index)["Volume"].fillna(0)

def resample_ohlc(df, rule):
    o = df["Open"].resample(rule).first()
    h = df["High"].resample(rule).max()
    l = df["Low"].resample(rule).min()
    c = df["Close"].resample(rule).last()
    v = df["VolProxy"].resample(rule).sum()
    out = pd.DataFrame({"Open":o,"High":h,"Low":l,"Close":c,"Volume":v}).dropna()
    return out

m5 = m5.tz_localize(None)
m15 = resample_ohlc(m5, "15T")
h1  = resample_ohlc(m5, "60T")

# ---------------- SMC building blocks ----------------
def pivots(df, left=3, right=3):
    w = left + right + 1
    ph = df["High"] == df["High"].rolling(w, center=True).max()
    pl = df["Low"]  == df["Low"].rolling(w, center=True).min()
    return ph.fillna(False), pl.fillna(False)

def last_pivot_value(df, mask, col):
    pivs = df[col][mask]
    return np.nan if pivs.empty else pivs.iloc[-1]

def fvg_bull(df, min_usd):
    gap = df["Low"] - df["High"].shift(2)
    return (gap > 0) & (gap >= min_usd)

def fvg_bear(df, min_usd):
    gap = df["Low"].shift(2) - df["High"]
    return (gap > 0) & (gap >= min_usd)

# pivots and BOS on M15 + H1
m15_ph, m15_pl = pivots(m15, 3, 3)
h1_ph,  h1_pl  = pivots(h1,  5, 5)

m15_last_hi = last_pivot_value(m15, m15_ph, "High")
m15_last_lo = last_pivot_value(m15, m15_pl, "Low")
h1_last_hi  = last_pivot_value(h1,  h1_ph,  "High")
h1_last_lo  = last_pivot_value(h1,  h1_pl,  "Low")

m15_bos_up  = (not np.isnan(m15_last_hi)) and (m15["Close"].iloc[-1] > m15_last_hi)
m15_bos_dn  = (not np.isnan(m15_last_lo)) and (m15["Close"].iloc[-1] < m15_last_lo)
h1_bos_up   = (not np.isnan(h1_last_hi))  and (h1["Close"].iloc[-1]  > h1_last_hi)
h1_bos_dn   = (not np.isnan(h1_last_lo))  and (h1["Close"].iloc[-1]  < h1_last_lo)

bias_bull = m15_bos_up and h1_bos_up
bias_bear = m15_bos_dn and h1_bos_dn

# FVG on M15 at the current bar
m15_fvgB = fvg_bull(m15, fvg_min_usd)
m15_fvgS = fvg_bear(m15, fvg_min_usd)

# OB from the previous M15 candle when BOS & FVG align
def current_ob(df, is_bull):
    if len(df) < 2:
        return (np.nan, np.nan)
    if is_bull:
        ob_low  = df["Low"].shift(1).iloc[-1]
        ob_high = df["Open"].shift(1).iloc[-1]
    else:
        ob_low  = df["Open"].shift(1).iloc[-1]
        ob_high = df["High"].shift(1).iloc[-1]
    if ob_high <= ob_low:
        return (np.nan, np.nan)
    return (ob_low, ob_high)

bull_ob_low = bull_ob_high = bear_ob_low = bear_ob_high = np.nan
if bias_bull and m15_fvgB.iloc[-1]:
    bull_ob_low, bull_ob_high = current_ob(m15, True)
if bias_bear and m15_fvgS.iloc[-1]:
    bear_ob_low, bear_ob_high = current_ob(m15, False)

have_bull_ob = not np.isnan(bull_ob_low) and not np.isnan(bull_ob_high)
have_bear_ob = not np.isnan(bear_ob_low) and not np.isnan(bear_ob_high)

# M5 volume filter & tap
vol_sma = m5["VolProxy"].rolling(int(vol_len)).mean()
vol_ok  = m5["VolProxy"].iloc[-1] > (vol_sma.iloc[-1] * float(vol_mult))

def session_ok(ts, sess):
    if sess == "0000-2400":
        return True
    try:
        start, end = sess.split("-")
        t = ts.tz_localize(None).time()
        from datetime import datetime as dt
        s = dt.strptime(start, "%H%M").time()
        e = dt.strptime(end, "%H%M").time()
        return (s <= t <= e) if s <= e else (t >= s or t <= e)
    except Exception:
        return True

in_session = session_ok(m5.index[-1], session_filter)

low_now, high_now = m5["Low"].iloc[-1], m5["High"].iloc[-1]
tap_bull = have_bull_ob and (low_now <= bull_ob_high) and (high_now >= bull_ob_low)
tap_bear = have_bear_ob and (low_now <= bear_ob_high) and (high_now >= bear_ob_low)

long_signal  = in_session and bias_bull and have_bull_ob and tap_bull and vol_ok
short_signal = in_session and bias_bear and have_bear_ob and tap_bear and vol_ok

# Targets/SL math
def midpoint(a,b): return (a+b)/2.0
entry_long = midpoint(bull_ob_low, bull_ob_high) if have_bull_ob else np.nan
sl_long    = (bull_ob_low - sl_usd) if have_bull_ob else np.nan

entry_short = midpoint(bear_ob_low, bear_ob_high) if have_bear_ob else np.nan
sl_short    = (bear_ob_high + sl_usd) if have_bear_ob else np.nan

# M5 swing pivots for TP1
def piv_last(df, left=3, right=3):
    w = left + right + 1
    ph = df["High"] == df["High"].rolling(w, center=True).max()
    pl = df["Low"]  == df["Low"].rolling(w, center=True).min()
    m5_last_hi = df["High"][ph].iloc[-1] if df["High"][ph].shape[0] else np.nan
    m5_last_lo = df["Low"][pl].iloc[-1]  if df["Low"][pl].shape[0]  else np.nan
    return m5_last_hi, m5_last_lo

m5_last_hi, m5_last_lo = piv_last(m5, 3, 3)

# H1 swings for TP2
h1_last_hi = last_pivot_value(h1, h1_ph, "High")
h1_last_lo = last_pivot_value(h1, h1_pl, "Low")

tp1_long = m5_last_hi
tp2_long = h1_last_hi
tp1_short = m5_last_lo
tp2_short = h1_last_lo

def rr_long(entry, sl, tp2):
    return (tp2 - entry) / max(0.01, entry - sl)

def rr_short(entry, sl, tp2):
    return (entry - tp2) / max(0.01, sl - entry)

rr_L = rr_long(entry_long, sl_long, tp2_long) if not any(map(np.isnan, [entry_long, sl_long, tp2_long])) else np.nan
rr_S = rr_short(entry_short, sl_short, tp2_short) if not any(map(np.isnan, [entry_short, sl_short, tp2_short])) else np.nan

def fmt(x): 
    return "na" if (x is None or np.isnan(x)) else f"{x:.2f}"

def payload(bias, entry, sl, tp1, tp2, rr):
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M")
    return f"{{{price_symbol}}}:{ts} | Bias:{bias} | Entry:{fmt(entry)} | SL:{fmt(sl)} | TP1:{fmt(tp1)} | TP2:{fmt(tp2)} | RR:{fmt(rr)} | Reason:BOS/CHOCH, OB, FVG, Liquidity, Volume | Timeframes:{{M5/M15/H1}}"

alert_long  = payload("bull", entry_long,  sl_long,  tp1_long,  tp2_long,  rr_L)
alert_short = payload("bear", entry_short, sl_short, tp1_short, tp2_short, rr_S)

# ---------------- Output ----------------
col1, col2 = st.columns([2,1])
with col1:
    st.subheader("Price (5m)")
    st.line_chart(m5["Close"])
    st.caption(f"Last price: {m5['Close'].iloc[-1]:.2f}")

with col2:
    st.subheader("Signal")
    if long_signal:
        st.success("LONG ✅")
        st.code(alert_long)
        if tg_enable and tg_token and tg_chat:
            try:
                requests.get(f"https://api.telegram.org/bot{tg_token}/sendMessage",
                             params={"chat_id": tg_chat, "text": alert_long, "parse_mode": "HTML"}, timeout=10)
                st.caption("Telegram sent.")
            except Exception as e:
                st.warning(f"Telegram error: {e}")
    elif short_signal:
        st.error("SHORT ✅")
        st.code(alert_short)
        if tg_enable and tg_token and tg_chat:
            try:
                requests.get(f"https://api.telegram.org/bot{tg_token}/sendMessage",
                             params={"chat_id": tg_chat, "text": alert_short, "parse_mode": "HTML"}, timeout=10)
                st.caption("Telegram sent.")
            except Exception as e:
                st.warning(f"Telegram error: {e}")
    else:
        st.info("No signal right now.")
        st.code(alert_long if bias_bull else alert_short)

st.markdown("---")
st.write({
    "bias_bull": bool(bias_bull), "bias_bear": bool(bias_bear),
    "have_bull_ob": bool(have_bull_ob), "have_bear_ob": bool(have_bear_ob),
    "tap_bull": bool(tap_bull), "tap_bear": bool(tap_bear), 
    "vol_ok": bool(vol_ok)
})

# Simple auto-refresh
if auto_refresh_sec > 0:
    time.sleep(int(auto_refresh_sec))
    st.rerun()
